import javax.swing.*;
import java.awt.*;

class AppGUI {
    private FlightManagementSystem sys;
    private JFrame mainFrame;
    private User currentUser;

    public AppGUI(FlightManagementSystem sys) {
        this.sys = sys;
        SwingUtilities.invokeLater(this::showLogin);
    }

    // --- Login UI ---
    private void showLogin() {
        JFrame f = new JFrame("Flight Manager - Login");
        f.setSize(440,260);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(new BorderLayout(8,8));

        JLabel header = new JLabel("Flight Management System", SwingConstants.CENTER);
        header.setFont(new Font("SansSerif", Font.BOLD, 18));
        f.add(header, BorderLayout.NORTH);

        JPanel center = new JPanel(new GridLayout(3,2,8,8));
        JTextField idF = new JTextField();
        JPasswordField pwF = new JPasswordField();
        center.add(new JLabel("User ID:"));
        center.add(idF);
        center.add(new JLabel("Password:"));
        center.add(pwF);

        JButton signIn = new JButton("Sign In");
        JButton signUp = new JButton("Sign Up (Passenger)");
        center.add(signIn); center.add(signUp);
        f.add(center, BorderLayout.CENTER);

        JLabel hint = new JLabel("<html>Default admin: <b>admin / admin123</b></html>", SwingConstants.CENTER);
        f.add(hint, BorderLayout.SOUTH);

        signIn.addActionListener(e -> {
            String id = idF.getText().trim();
            String pw = new String(pwF.getPassword()).trim();
            if (id.isEmpty() || pw.isEmpty()) { JOptionPane.showMessageDialog(f, "Enter ID & Password"); return; }
            User u = sys.signIn(id, pw);
            if (u == null) { JOptionPane.showMessageDialog(f, "Login failed"); return; }

            currentUser = u;
            f.dispose();
            if ("ADMIN".equals(u.getRole())) showAdminDashboard();
            else showPassengerDashboard();
        });

        signUp.addActionListener(e -> { f.dispose(); showSignUp(); });

        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    // ------------ SIGNUP -------------
    private void showSignUp() {
        JFrame f = new JFrame("Passenger Sign Up");
        f.setSize(440,320);
        f.setLayout(new GridLayout(6,2,8,8));

        JTextField idF = new JTextField(), nameF = new JTextField(), emailF = new JTextField();
        JPasswordField pwF = new JPasswordField();

        f.add(new JLabel("Choose ID:")); f.add(idF);
        f.add(new JLabel("Name:"));     f.add(nameF);
        f.add(new JLabel("Email:"));    f.add(emailF);
        f.add(new JLabel("Password:")); f.add(pwF);

        JButton create = new JButton("Create");
        JButton back = new JButton("Back");
        f.add(create); f.add(back);

        create.addActionListener(e -> {
            String id=idF.getText().trim(), nm=nameF.getText().trim(),
                    em=emailF.getText().trim(), pw=new String(pwF.getPassword()).trim();

            if (id.isEmpty() || nm.isEmpty() || em.isEmpty() || pw.isEmpty()) {
                JOptionPane.showMessageDialog(f,"Fill all fields"); return;
            }
            if (sys.signUpPassenger(id,nm,em,pw)) {
                JOptionPane.showMessageDialog(f,"Account created!");
                f.dispose(); showLogin();
            } else JOptionPane.showMessageDialog(f,"ID already exists.");
        });

        back.addActionListener(e -> { f.dispose(); showLogin(); });

        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    // --- Admin Dashboard ---
    private void showAdminDashboard() {
        JFrame f = new JFrame("Admin Dashboard - " + currentUser.getName());
        f.setSize(900,520);
        f.setLayout(new BorderLayout(8,8));

        JLabel top = new JLabel("Admin Dashboard", SwingConstants.CENTER);
        top.setFont(new Font("SansSerif", Font.BOLD, 18));
        f.add(top, BorderLayout.NORTH);

        DefaultListModel<String> flightsModel = new DefaultListModel<>();
        DefaultListModel<String> bookingsModel = new DefaultListModel<>();

        JList<String> flightsList = new JList<>(flightsModel);
        JList<String> bookingsList = new JList<>(bookingsModel);

        refreshFlightsModel(flightsModel);
        refreshBookingsModel(bookingsModel);

        JPanel center = new JPanel(new GridLayout(1,2,8,8));

        JPanel left = new JPanel(new BorderLayout());
        left.add(new JLabel("Flights", SwingConstants.CENTER), BorderLayout.NORTH);
        left.add(new JScrollPane(flightsList));

        JPanel right = new JPanel(new BorderLayout());
        right.add(new JLabel("Bookings", SwingConstants.CENTER), BorderLayout.NORTH);
        right.add(new JScrollPane(bookingsList));

        center.add(left); center.add(right);

        f.add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(2,4,8,8));

        JButton addFlight = new JButton("Add Flight");
        JButton delFlight = new JButton("Delete Flight");
        JButton viewPass = new JButton("View Passengers");
        JButton cancelBook = new JButton("Cancel Booking");
        JButton logout = new JButton("Logout");

        bottom.add(addFlight); bottom.add(delFlight);
        bottom.add(viewPass);  bottom.add(cancelBook);
        bottom.add(new JLabel()); bottom.add(new JLabel());
        bottom.add(new JLabel()); bottom.add(logout);

        f.add(bottom, BorderLayout.SOUTH);

        addFlight.addActionListener(e -> showAddFlightWindow(() -> {
            refreshFlightsModel(flightsModel);
            refreshBookingsModel(bookingsModel);
        }));

        delFlight.addActionListener(e -> {
            String sel = flightsList.getSelectedValue();
            if (sel == null) { JOptionPane.showMessageDialog(f,"Select flight"); return; }
            String id = sel.split(" ")[0];
            int c = JOptionPane.showConfirmDialog(f,"Delete " + id + " ?","Confirm",JOptionPane.YES_NO_OPTION);
            if (c == JOptionPane.YES_OPTION) {
                sys.removeFlight(id);
                refreshFlightsModel(flightsModel);
                refreshBookingsModel(bookingsModel);
            }
        });

        viewPass.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (User u : sys.getUsers())
                if ("PASSENGER".equals(u.getRole()))
                    sb.append(u).append("\n");

            JTextArea ta = new JTextArea(sb.toString());
            ta.setEditable(false);
            JOptionPane.showMessageDialog(f,new JScrollPane(ta),"Passengers",JOptionPane.PLAIN_MESSAGE);
        });

        cancelBook.addActionListener(e -> {
            String sel = bookingsList.getSelectedValue();
            if (sel == null) { JOptionPane.showMessageDialog(f,"Select booking"); return; }
            String bid = sel.substring(1, sel.indexOf(']'));
            sys.adminCancelBooking(bid);
            refreshBookingsModel(bookingsModel);
            refreshFlightsModel(flightsModel);
        });

        logout.addActionListener(e -> { f.dispose(); currentUser=null; showLogin(); });

        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    private void refreshFlightsModel(DefaultListModel<String> m) {
        m.clear();
        for (Flight f : sys.getFlights()) m.addElement(f.toString());
    }

    private void refreshBookingsModel(DefaultListModel<String> m) {
        m.clear();
        for (Booking b : sys.getBookings())
            m.addElement("[" + b.id + "] " + b.passengerId + " -> " + b.flightId + " @ " + b.time.format(Const.DT_FMT));
    }

    private void showAddFlightWindow(Runnable onAdded) {
        JDialog d = new JDialog((Frame)null,"Add Flight",true);
        d.setSize(460,360);
        d.setLayout(new GridLayout(7,2,8,8));

        JTextField idF=new JTextField(), airlineF=new JTextField(), srcF=new JTextField(),
                destF=new JTextField(), seatsF=new JTextField(), depF=new JTextField();

        d.add(new JLabel("Flight ID:")); d.add(idF);
        d.add(new JLabel("Airline:")); d.add(airlineF);
        d.add(new JLabel("Source:")); d.add(srcF);
        d.add(new JLabel("Destination:")); d.add(destF);
        d.add(new JLabel("Total Seats:")); d.add(seatsF);
        d.add(new JLabel("Departure (yyyy-MM-dd HH:mm):")); d.add(depF);

        JButton add = new JButton("Add");
        JButton cancel = new JButton("Cancel");
        d.add(add); d.add(cancel);

        add.addActionListener(e -> {
            try {
                Flight fl = new Flight(
                        idF.getText().trim(), airlineF.getText().trim(),
                        srcF.getText().trim(), destF.getText().trim(),
                        Integer.parseInt(seatsF.getText().trim()),
                        java.time.LocalDateTime.parse(depF.getText().trim(), Const.DT_FMT)
                );

                if (sys.addFlight(fl)) {
                    JOptionPane.showMessageDialog(d,"Added");
                    d.dispose();
                    if (onAdded != null) onAdded.run();
                } else JOptionPane.showMessageDialog(d,"ID exists");

            } catch(Exception ex) { JOptionPane.showMessageDialog(d,"Invalid input"); }
        });

        cancel.addActionListener(e -> d.dispose());

        d.setLocationRelativeTo(null);
        d.setVisible(true);
    }

    // --- Passenger Dashboard ---
    private void showPassengerDashboard() {
        JFrame f = new JFrame("Passenger Dashboard - " + currentUser.getName());
        f.setSize(900,520);
        f.setLayout(new BorderLayout(8,8));

        JLabel top = new JLabel("Passenger Dashboard", SwingConstants.CENTER);
        top.setFont(new Font("SansSerif", Font.BOLD, 18));
        f.add(top, BorderLayout.NORTH);

        DefaultListModel<String> flightsModel = new DefaultListModel<>();
        DefaultListModel<String> myBookingsModel = new DefaultListModel<>();

        JList<String> flightsList = new JList<>(flightsModel);
        JList<String> myBookingsList = new JList<>(myBookingsModel);

        refreshFlightsModel(flightsModel);
        refreshMyBookingsModel(myBookingsModel, currentUser.getId());

        JPanel left = new JPanel(new BorderLayout());
        left.add(new JLabel("Flights", SwingConstants.CENTER), BorderLayout.NORTH);
        left.add(new JScrollPane(flightsList));

        JPanel right = new JPanel(new BorderLayout());
        right.add(new JLabel("Bookings", SwingConstants.CENTER), BorderLayout.NORTH);
        right.add(new JScrollPane(myBookingsList));

        JPanel center = new JPanel(new GridLayout(1,2,8,8));
        center.add(left); center.add(right);

        f.add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(1,4,8,8));
        JButton book = new JButton("Book Selected Flight");
        JButton cancel = new JButton("Cancel Selected Booking");
        JButton logout = new JButton("Logout");

        bottom.add(book); bottom.add(cancel); bottom.add(new JLabel()); bottom.add(logout);
        f.add(bottom, BorderLayout.SOUTH);

        book.addActionListener(e -> {
            String sel = flightsList.getSelectedValue();
            if (sel == null) { JOptionPane.showMessageDialog(f,"Select flight"); return; }
            String fid = sel.split(" ")[0];
            Booking b = sys.bookFlight(currentUser.getId(), fid);
            if (b == null) JOptionPane.showMessageDialog(f,"Booking failed");
            else {
                JOptionPane.showMessageDialog(f,"Booked! ID: " + b.id);
                refreshFlightsModel(flightsModel);
                refreshMyBookingsModel(myBookingsModel, currentUser.getId());
            }
        });

        cancel.addActionListener(e -> {
            String sel = myBookingsList.getSelectedValue();
            if (sel == null) { JOptionPane.showMessageDialog(f,"Select booking"); return; }
            String bid = sel.substring(1, sel.indexOf(']'));
            if (sys.cancelBooking(bid, currentUser.getId())) {
                JOptionPane.showMessageDialog(f,"Cancelled");
                refreshFlightsModel(flightsModel);
                refreshMyBookingsModel(myBookingsModel, currentUser.getId());
            } else JOptionPane.showMessageDialog(f,"Cancel failed");
        });

        logout.addActionListener(e -> { f.dispose(); currentUser = null; showLogin(); });

        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    private void refreshMyBookingsModel(DefaultListModel<String> m, String pid) {
        m.clear();
        for (Booking b : sys.getBookings())
            if (b.passengerId.equals(pid))
                m.addElement("[" + b.id + "] " + b.flightId + " @ " + b.time.format(Const.DT_FMT));
    }
}
