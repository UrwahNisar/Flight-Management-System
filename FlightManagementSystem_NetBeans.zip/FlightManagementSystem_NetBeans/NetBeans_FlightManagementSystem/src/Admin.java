class Admin extends User {
    public Admin(String id, String name, String email, String pw) {
        super(id,name,email,pw);
    }
    @Override public String getRole() { return "ADMIN"; }
}
