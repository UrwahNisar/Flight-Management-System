import java.util.*;
import java.time.LocalDateTime;

class FlightManagementSystem {
    private List<User> users;
    private List<Flight> flights;
    private List<Booking> bookings;

    public FlightManagementSystem() {
        users = FileStorage.loadUsers();
        flights = FileStorage.loadFlights();
        bookings = FileStorage.loadBookings();
        ensureAdmin();
    }

    private void ensureAdmin() {
        boolean hasAdmin = false;
        for (User u : users)
            if ("ADMIN".equals(u.getRole())) { hasAdmin = true; break; }

        if (!hasAdmin) {
            users.add(new Admin("admin", "Administrator", "admin@example.com", "admin123"));
            FileStorage.saveUsers(users);
        }
    }

    public boolean signUpPassenger(String id, String name, String email, String pw) {
        if (findUserById(id) != null) return false;
        users.add(new Passenger(id, name, email, pw));
        FileStorage.saveUsers(users);
        return true;
    }

    public User signIn(String id, String pw) {
        User u = findUserById(id);
        if (u != null && u.checkPassword(pw)) return u;
        return null;
    }

    private User findUserById(String id) {
        for (User u : users)
            if (u.getId().equals(id)) return u;
        return null;
    }

    public boolean addFlight(Flight f) {
        if (findFlightById(f.id) != null) return false;
        flights.add(f);
        FileStorage.saveFlights(flights);
        return true;
    }

    public boolean removeFlight(String flightId) {
        Flight f = findFlightById(flightId);
        if (f == null) return false;

        bookings.removeIf(b -> b.flightId.equals(flightId));
        flights.remove(f);

        FileStorage.saveBookings(bookings);
        FileStorage.saveFlights(flights);
        return true;
    }

    public Flight findFlightById(String id) {
        for (Flight f : flights) if (f.id.equals(id)) return f;
        return null;
    }

    public List<Flight> getFlights() { return flights; }

    public Booking bookFlight(String passengerId, String flightId) {
        User u = findUserById(passengerId);
        if (!(u instanceof Passenger)) return null;

        Flight f = findFlightById(flightId);
        if (f == null || !f.bookSeat()) return null;

        Booking b = new Booking(passengerId, flightId);
        bookings.add(b);

        FileStorage.saveBookings(bookings);
        FileStorage.saveFlights(flights);
        return b;
    }

    public boolean cancelBooking(String bookingId, String passengerId) {
        Booking target = null;

        for (Booking b : bookings)
            if (b.id.equals(bookingId) && b.passengerId.equals(passengerId)) {
                target = b; break;
            }

        if (target == null) return false;

        Flight f = findFlightById(target.flightId);
        if (f != null) f.cancelSeat();

        bookings.remove(target);

        FileStorage.saveBookings(bookings);
        FileStorage.saveFlights(flights);
        return true;
    }

    public boolean adminCancelBooking(String bookingId) {
        Booking target = null;
        for (Booking b : bookings)
            if (b.id.equals(bookingId)) { target = b; break; }

        if (target == null) return false;

        Flight f = findFlightById(target.flightId);
        if (f != null) f.cancelSeat();

        bookings.remove(target);

        FileStorage.saveBookings(bookings);
        FileStorage.saveFlights(flights);
        return true;
    }

    public List<Booking> getBookings() { return bookings; }
    public List<User> getUsers() { return users; }
}
