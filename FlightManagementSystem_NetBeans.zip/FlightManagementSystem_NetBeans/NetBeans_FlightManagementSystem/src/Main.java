public class Main {
    public static void main(String[] args) {
        FlightManagementSystem sys = new FlightManagementSystem();
        new AppGUI(sys);
    }
}
