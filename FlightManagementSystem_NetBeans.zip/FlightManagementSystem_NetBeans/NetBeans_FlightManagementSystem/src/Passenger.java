class Passenger extends User {
    public Passenger(String id, String name, String email, String pw) {
        super(id,name,email,pw);
    }
    @Override public String getRole() { return "PASSENGER"; }
}
