import java.time.format.DateTimeFormatter;

class Const {
    public static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    public static final String USERS_FILE = "users.txt";       // role,id,name,email,password
    public static final String FLIGHTS_FILE = "flights.txt";   // id,airline,source,dest,totalSeats,bookedSeats,departure
    public static final String BOOKINGS_FILE = "bookings.txt"; // id,passengerId,flightId,time
}
