abstract class User {
    protected String id;
    protected String name;
    protected String email;
    protected String password;

    public User(String id, String name, String email, String password) {
        this.id = id; this.name = name; this.email = email; this.password = password;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public boolean checkPassword(String pw) { return password.equals(pw); }
    public abstract String getRole();
    public String toFileString() { return getRole() + "," + id + "," + name + "," + email + "," + password; }
    @Override public String toString() { return name + " (" + id + ")"; }
}
