import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

class FileStorage {

    // Load users
    public static List<User> loadUsers() {
        List<User> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(Const.USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] a = line.split(",", 5);
                if (a.length < 5) continue;
                String role = a[0], id = a[1], name = a[2], email = a[3], pw = a[4];
                if ("ADMIN".equals(role)) list.add(new Admin(id, name, email, pw));
                else list.add(new Passenger(id, name, email, pw));
            }
        } catch (IOException ignored) {}
        return list;
    }

    public static void saveUsers(List<User> users) {
        try (PrintWriter pw = new PrintWriter(Const.USERS_FILE)) {
            for (User u : users) pw.println(u.toFileString());
        } catch (IOException e) { e.printStackTrace(); }
    }

    // Load flights
    public static List<Flight> loadFlights() {
        List<Flight> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(Const.FLIGHTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] a = line.split(",", 7);
                if (a.length < 7) continue;
                Flight f = new Flight(a[0], a[1], a[2], a[3], Integer.parseInt(a[4]),
                        LocalDateTime.parse(a[6], Const.DT_FMT));
                f.bookedSeats = Integer.parseInt(a[5]);
                list.add(f);
            }
        } catch (IOException ignored) {}
        return list;
    }

    public static void saveFlights(List<Flight> flights) {
        try (PrintWriter pw = new PrintWriter(Const.FLIGHTS_FILE)) {
            for (Flight f : flights) pw.println(f.toFileString());
        } catch (IOException e) { e.printStackTrace(); }
    }

    // Load bookings
    public static List<Booking> loadBookings() {
        List<Booking> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(Const.BOOKINGS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] a = line.split(",", 4);
                if (a.length < 4) continue;
                list.add(new Booking(a[0], a[1], a[2], LocalDateTime.parse(a[3], Const.DT_FMT)));
            }
        } catch (IOException ignored) {}
        return list;
    }

    public static void saveBookings(List<Booking> bookings) {
        try (PrintWriter pw = new PrintWriter(Const.BOOKINGS_FILE)) {
            for (Booking b : bookings) pw.println(b.toFileString());
        } catch (IOException e) { e.printStackTrace(); }
    }
}
