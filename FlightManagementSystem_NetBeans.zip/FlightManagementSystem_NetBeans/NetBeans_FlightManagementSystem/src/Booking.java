import java.time.LocalDateTime;

class Booking {
    private static int counter = 1;

    String id;
    String passengerId;
    String flightId;
    LocalDateTime time;

    public Booking(String passengerId, String flightId) {
        this.id = "B" + counter++;
        this.passengerId = passengerId;
        this.flightId = flightId;
        this.time = LocalDateTime.now();
    }

    public Booking(String id, String passengerId, String flightId, LocalDateTime time) {
        this.id = id;
        this.passengerId = passengerId;
        this.flightId = flightId;
        this.time = time;
    }

    public String toFileString() {
        return id + "," + passengerId + "," + flightId + "," + time.format(Const.DT_FMT);
    }

    @Override
    public String toString() {
        return "[" + id + "] " + passengerId + " -> " + flightId + " @ " + time.format(Const.DT_FMT);
    }
}
