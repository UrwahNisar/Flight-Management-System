import java.time.LocalDateTime;

class Flight {
    String id, airline, source, destination;
    int totalSeats;
    int bookedSeats;
    LocalDateTime departure;

    public Flight(String id, String airline, String source, String destination, int totalSeats, LocalDateTime departure) {
        this.id = id;
        this.airline = airline;
        this.source = source;
        this.destination = destination;
        this.totalSeats = totalSeats;
        this.bookedSeats = 0;
        this.departure = departure;
    }

    public boolean bookSeat() {
        if (bookedSeats < totalSeats) { bookedSeats++; return true; }
        return false;
    }
    public boolean cancelSeat() {
        if (bookedSeats > 0) { bookedSeats--; return true; }
        return false;
    }

    public String toFileString() {
        return id + "," + airline + "," + source + "," + destination + "," +
                totalSeats + "," + bookedSeats + "," + departure.format(Const.DT_FMT);
    }

    @Override
    public String toString() {
        return id + " - " + airline + " | " + source + " → " + destination +
                " [" + bookedSeats + "/" + totalSeats + "] Dep: " + departure.format(Const.DT_FMT);
    }
}
